from db.tusimple import TUSIMPLE
from db.culane import CULANE

datasets = {
    "TUSIMPLE": TUSIMPLE,
    "CULANE": CULANE,
}
